// admin.js - painel de criador simples (usa localStorage)
const pinInput = document.getElementById('pinInput');
const setPinBtn = document.getElementById('setPinBtn');
const adminArea = document.getElementById('adminArea');
const authArea = document.getElementById('authArea');
const questionsJson = document.getElementById('questionsJson');
const saveQuestions = document.getElementById('saveQuestions');
const customLink = document.getElementById('customLink');
const accentColor = document.getElementById('accentColor');
const saveConfig = document.getElementById('saveConfig');
const exportBtn = document.getElementById('exportBtn');
const importBtn = document.getElementById('importBtn');
const logoutBtn = document.getElementById('logoutBtn');

function isAuthenticated() {
  return localStorage.getItem('creator_authenticated') === '1';
}

function showAdmin() {
  authArea.style.display = 'none';
  adminArea.style.display = '';
  // load current questions
  const q = localStorage.getItem('questionsData') || localStorage.getItem('questionsRaw') || '';
  questionsJson.value = q || JSON.stringify([], null, 2);
  const cfg = JSON.parse(localStorage.getItem('appConfig') || '{}');
  customLink.value = cfg.customLink || 'https://desafioqi.app';
  accentColor.value = cfg.accentColor || '#ffd400';
}

setPinBtn.addEventListener('click', () => {
  const pin = pinInput.value.trim();
  if (!pin) { alert('Digite um PIN'); return; }
  const existing = localStorage.getItem('creator_pin');
  if (!existing) {
    localStorage.setItem('creator_pin', pin);
    localStorage.setItem('creator_authenticated', '1');
    alert('PIN criado e você está autenticado');
    showAdmin();
  } else {
    if (pin === existing) {
      localStorage.setItem('creator_authenticated', '1');
      alert('Autenticado');
      showAdmin();
    } else {
      alert('PIN incorreto');
    }
  }
});

if (isAuthenticated()) showAdmin();

saveQuestions.addEventListener('click', () => {
  try {
    const parsed = JSON.parse(questionsJson.value);
    localStorage.setItem('questionsData', JSON.stringify(parsed));
    alert('Perguntas salvas com sucesso!');
  } catch (e) {
    alert('JSON inválido: ' + e);
  }
});

saveConfig.addEventListener('click', () => {
  const cfg = { customLink: customLink.value || 'https://desafioqi.app', accentColor: accentColor.value || '#ffd400' };
  localStorage.setItem('appConfig', JSON.stringify(cfg));
  alert('Configurações salvas. Reabra a página para ver mudanças.');
});

exportBtn.addEventListener('click', () => {
  const data = {
    questions: JSON.parse(localStorage.getItem('questionsData') || '[]'),
    config: JSON.parse(localStorage.getItem('appConfig') || '{}'),
    ranking: JSON.parse(localStorage.getItem('rankingQI') || '[]')
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = 'desafioqi_export.json'; a.click();
});

importBtn.addEventListener('click', () => {
  const txt = prompt('Cole aqui o JSON exportado');
  if (!txt) return;
  try {
    const data = JSON.parse(txt);
    if (data.questions) localStorage.setItem('questionsData', JSON.stringify(data.questions));
    if (data.config) localStorage.setItem('appConfig', JSON.stringify(data.config));
    if (data.ranking) localStorage.setItem('rankingQI', JSON.stringify(data.ranking));
    alert('Importado com sucesso. Recarregue as páginas para ver alterações.');
  } catch (e) { alert('JSON inválido: '+e); }
});

logoutBtn.addEventListener('click', () => {
  localStorage.removeItem('creator_authenticated');
  alert('Deslogado');
  location.href = 'index.html';
});
