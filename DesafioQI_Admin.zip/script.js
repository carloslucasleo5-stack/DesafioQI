
// load questions from localStorage (admin editable) if present
const storedQ = localStorage.getItem('questionsData');
if (storedQ) {
  try { const parsed = JSON.parse(storedQ); if (Array.isArray(parsed) && parsed.length>0) { window.questions = parsed; } } catch(e){console.error('Invalid stored questions', e); }
}
// load config (custom link, accent color)
const appConfig = JSON.parse(localStorage.getItem('appConfig') || '{}');
const CUSTOM_LINK = appConfig.customLink || 'https://desafioqi.app';
const ACCENT_COLOR = appConfig.accentColor || '#ffd400';
// script.js - lógica do Desafio QI (PWA) com compartilhamento

// Perguntas (exemplo). Edite para adicionar mais.
const questions = [
  {
    text: "Se todos os gatos são felinos e alguns felinos são brancos, pode-se concluir que alguns gatos são brancos?",
    options: [
      { text: "Sim, necessariamente", points: 0 },
      { text: "Não necessariamente", points: 2 },
      { text: "Somente se todos forem brancos", points: 0 },
      { text: "Indeterminado", points: 1 }
    ]
  },
  {
    text: "Qual número completa a sequência: 2, 6, 18, 54, __ ?",
    options: [
      { text: "108", points: 0 },
      { text: "162", points: 2 },
      { text: "156", points: 0 },
      { text: "216", points: 0 }
    ]
  },
  {
    text: "Se um relógio adianta 10 min a cada 2h, em quantas horas adianta 1h?",
    options: [
      { text: "10 horas", points: 0 },
      { text: "20 horas", points: 2 },
      { text: "12 horas", points: 0 },
      { text: "6 horas", points: 0 }
    ]
  },
  {
    text: "Qual figura não pertence: círculo, quadrado, triângulo, retângulo?",
    options: [
      { text: "Círculo", points: 2 },
      { text: "Quadrado", points: 0 },
      { text: "Triângulo", points: 0 },
      { text: "Retângulo", points: 0 }
    ]
  },
  {
    text: "Se A > B e B > C, então:",
    options: [
      { text: "A > C", points: 2 },
      { text: "A < C", points: 0 },
      { text: "A = C", points: 0 },
      { text: "Indeterminado", points: 0 }
    ]
  }
];

let current = 0;
let answers = new Array(questions.length).fill(null);
let totalTime = 0;
let timerInterval;
let timeLeft = 30;

const container = document.getElementById("question-container");
const prevBtn = document.getElementById("prevBtn");
const nextBtn = document.getElementById("nextBtn");
const progress = document.getElementById("progress");
const timerEl = document.getElementById("timer");

const soundCorrect = document.getElementById("sound-correct");
const soundWrong = document.getElementById("sound-wrong");

if (container) renderQuestion(current);

function startTimer() {
  clearInterval(timerInterval);
  timeLeft = 30;
  timerEl.textContent = `⏳ ${timeLeft}s`;
  timerInterval = setInterval(() => {
    timeLeft--;
    timerEl.textContent = `⏳ ${timeLeft}s`;
    if (timeLeft <= 0) {
      clearInterval(timerInterval);
      totalTime += 30;
      if (current < questions.length - 1) {
        current++;
        renderQuestion(current);
      } else {
        finalizar();
      }
    }
  }, 1000);
}

function renderQuestion(index) {
  const q = questions[index];
  container.innerHTML = `
    <p><strong>${index + 1}. ${q.text}</strong></p>
    ${q.options
      .map(
        (o, i) => `
      <div class="option ${answers[index] === i ? "selected" : ""}" onclick="selectOption(${index}, ${i})">
        ${o.text}
      </div>
    `
      )
      .join("")}
  `;
  progress.textContent = `Pergunta ${index + 1} de ${questions.length}`;
  prevBtn.disabled = index === 0;
  nextBtn.textContent = index === questions.length - 1 ? "Finalizar" : "Próxima";
  startTimer();
}

function selectOption(qIndex, oIndex) {
  const pts = questions[qIndex].options[oIndex].points || 0;
  const correct = pts > 0;
  answers[qIndex] = oIndex;
  if (correct) {
    if (soundCorrect) try{ soundCorrect.play(); }catch(e){}
  } else {
    if (soundWrong) try{ soundWrong.play(); }catch(e){}
  }
  clearInterval(timerInterval);
  setTimeout(()=> {
    if (current < questions.length - 1) {
      totalTime += (30 - timeLeft);
      current++;
      renderQuestion(current);
    } else {
      totalTime += (30 - timeLeft);
      finalizar();
    }
  }, 300);
}

nextBtn?.addEventListener("click", () => {
  totalTime += (30 - timeLeft);
  if (current < questions.length - 1) {
    current++;
    renderQuestion(current);
  } else {
    finalizar();
  }
});

prevBtn?.addEventListener("click", () => {
  if (current > 0) {
    current--;
    renderQuestion(current);
  }
});

function finalizar() {
  clearInterval(timerInterval);
  let points = 0;
  let max = 0;

  questions.forEach((q, i) => {
    const sel = answers[i];
    if (sel !== null) points += q.options[sel].points;
    max += Math.max(...q.options.map(o => o.points));
  });

  const percent = Math.round((points / max) * 100);
  const score = Math.round(100 + (points / max - 0.5) * 30);

  let message = "";
  if (score >= 130) message = "QI muito alto!";
  else if (score >= 115) message = "Acima da média!";
  else if (score >= 85) message = "Na média.";
  else message = "Abaixo da média";

  localStorage.setItem("qiResult", JSON.stringify({
    points, max, percent, score, message, time: totalTime
  }));

  window.location.href = "resultado.html";
}

// --- Compartilhamento de resultados com imagem ---
document.addEventListener('DOMContentLoaded', () => {
  const shareBtn = document.getElementById('shareBtn');
  if (shareBtn) {
    shareBtn.addEventListener('click', async () => {
      const result = JSON.parse(localStorage.getItem("qiResult")) || {};
      if(!result.score) return alert('Nenhum resultado encontrado.');

      let frase = '';
      if(result.score >= 130) frase = '🧠 Gênio absoluto! Desafie seus amigos!';
      else if(result.score >= 115) frase = '💡 Acima da média! Será que eles conseguem bater você?';
      else if(result.score >= 85) frase = '🤔 Na média! Tente desafiar seus amigos!';
      else frase = '⚡ Precisando treinar! Aceita o desafio?';

      const canvas = document.getElementById('shareCanvas');
      const ctx = canvas.getContext('2d');
      canvas.width = 1080; canvas.height = 1920;
      ctx.fillStyle = '#000'; ctx.fillRect(0,0,canvas.width,canvas.height);
      ctx.fillStyle = ACCENT_COLOR; ctx.font = 'bold 80px Orbitron'; ctx.textAlign='center';
      ctx.fillText('Desafio QI', canvas.width/2, 200);
      ctx.fillStyle = '#fff'; ctx.font='bold 120px Orbitron'; ctx.fillText(result.score+' pts', canvas.width/2, 600);
      ctx.fillStyle=ACCENT_COLOR; ctx.font='bold 60px Inter'; ctx.fillText(frase, canvas.width/2, 900);
      ctx.fillStyle='#fff'; ctx.font='bold 40px Inter'; ctx.fillText('Jogue também: '+CUSTOM_LINK, canvas.width/2, 1100);
      const imageData = canvas.toDataURL('image/png');

      if(navigator.canShare && navigator.canShare({ files: [] })) {
        fetch(imageData).then(r=>r.blob()).then(blob=>{
          const file = new File([blob],'DesafioQI.png',{type:'image/png'});
          navigator.share({files:[file], title:'Desafio QI', text:frase});
        }).catch(e=>alert('Erro ao compartilhar: '+e));
      } else {
        const w = window.open('');
        w.document.write('<img src="'+imageData+'" style="width:100%">');
        w.document.title = 'Compartilhe sua pontuação!';
      }
    });
  }
});


// shareOtherBtn handler (WhatsApp/others)
document.addEventListener('DOMContentLoaded', () => {
  const shareOtherBtn = document.getElementById('shareOtherBtn');
  if (shareOtherBtn) {
    shareOtherBtn.addEventListener('click', async () => {
      const result = JSON.parse(localStorage.getItem("qiResult")) || {};
      if(!result.score) return alert('Nenhum resultado encontrado.');
      let frase = '';
      if(result.score >= 130) frase = '🧠 Gênio absoluto! Desafie seus amigos!';
      else if(result.score >= 115) frase = '💡 Acima da média! Será que eles conseguem bater você?';
      else if(result.score >= 85) frase = '🤔 Na média! Tente desafiar seus amigos!';
      else frase = '⚡ Precisando treinar! Aceita o desafio?';
      const canvas = document.getElementById('shareCanvas');
      const imageData = canvas.toDataURL('image/png');
      // Try native share with files
      if (navigator.canShare && navigator.canShare({ files: [] })) {
        try {
          const res = await fetch(imageData);
          const blob = await res.blob();
          const file = new File([blob], 'DesafioQI.png', { type: 'image/png' });
          await navigator.share({ files: [file], title: 'Desafio QI', text: frase + ' ' + CUSTOM_LINK });
          return;
        } catch (e) { console.warn('native share failed', e); }
      }
      // Fallback: open WhatsApp web with text and link
      const text = encodeURIComponent(frase + ' Jogue também: ' + CUSTOM_LINK);
      const waUrl = 'https://wa.me/?text=' + text;
      window.open(waUrl, '_blank');
    });
  }
});
